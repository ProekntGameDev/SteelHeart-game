namespace Zenject
{
    public static class CompositeInstallerEditorDescriptions
    {
        public const string ErrorTooltip = "WARNING: This composite installer has some circular references and will cause an exception";
    }
}