using UnityEngine;

namespace Zenject.Asteroids
{
    public class ExplosionFactory : PlaceholderFactory<Transform>
    {
    }
}

