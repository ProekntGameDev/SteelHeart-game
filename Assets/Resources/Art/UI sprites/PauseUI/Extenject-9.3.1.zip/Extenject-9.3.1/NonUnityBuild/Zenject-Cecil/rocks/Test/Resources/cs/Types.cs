public class Foo {

	public class Bar {
	}

	public class Gazonk {

		public class Baz {
		}
	}
}

public class Pan {
}
