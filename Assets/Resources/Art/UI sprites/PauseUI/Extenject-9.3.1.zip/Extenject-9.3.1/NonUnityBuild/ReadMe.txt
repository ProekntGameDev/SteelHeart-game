
If you wish to use Zenject outside of unity, you can build it by compiling the solution provided in this folder.

The files should appear in a Bin directory in this same directory
