---
name: Other
about: Other
title: ''
labels: ''
assignees: ''

---

> **Note:** Please don't file an issue to ask a question. You'll get faster results by using the resources below.

:rocket: **Chat (recommended):**
* [Extenject community on Gitter](https://gitter.im/Extenject/community) (Official)
* [Infallible Code's Discord](https://discord.gg/T5y5TD) (has an #Extenject-Zenject channel)

:snail: **Websites/forums:**
* [StackOverflow](https://stackoverflow.com/questions/tagged/zenject)
* [Unity Forums](https://forum.unity.com/threads/zenject-dependency-injection-framework-for-unity.201184/)
