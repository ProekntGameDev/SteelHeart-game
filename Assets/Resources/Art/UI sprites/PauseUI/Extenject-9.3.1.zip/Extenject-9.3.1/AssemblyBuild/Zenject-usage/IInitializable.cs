namespace Zenject
{
    public interface IInitializable
    {
        void Initialize();
    }
}
