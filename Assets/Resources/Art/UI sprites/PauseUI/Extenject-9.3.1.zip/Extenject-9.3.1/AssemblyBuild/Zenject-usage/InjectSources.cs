namespace Zenject
{
    public enum InjectSources
    {
        Any,
        Local,
        Parent,
        AnyParent,
    }
}
